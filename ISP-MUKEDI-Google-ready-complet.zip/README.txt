# Site web ISP-MUKEDI

Prototype responsive de la page institutionnelle de l'Institut Supérieur Pédagogique de Mukedi.

## Utilisation
Ouvrir `index.html` dans un navigateur.

## À prévoir pour la version production
- connecter le formulaire à un serveur/base de données ;
- créer un espace administrateur ;
- gérer les comptes étudiants ;
- remplacer les coordonnées/e-mails par les coordonnées officiellement validées ;
- ajouter HTTPS, sauvegardes et gestion des droits.
